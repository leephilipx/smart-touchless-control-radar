# XM112

## Overview

The XM112 module is tailored for customer evaluation and for OEMs who wish to have the shortest time-to-market.

XM112 can be used as a controlled module, application running on external host where XM112 is controlled by register based protocol. This can be achieved by using the module software.

## Product documents

To view release notes use the following link:
https://developer.acconeer.com/sw-release-notes/

For detailed documentation, head over to the [Acconeer website](https://www.acconeer.com/products).
