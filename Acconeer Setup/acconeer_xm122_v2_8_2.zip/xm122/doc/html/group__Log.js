var group__Log =
[
    [ "acc_rss_integration_log_t", "structacc__rss__integration__log__t.html", [
      [ "log", "structacc__rss__integration__log__t.html#ab6bf2d78ee8388a7943656c480c8e5ed", null ],
      [ "log_level", "structacc__rss__integration__log__t.html#a401ee48ba02cd63c873e85093cbb728a", null ]
    ] ],
    [ "acc_log_function_t", "group__Log.html#ga1bdb7466d8585430cece18820421628d", null ],
    [ "acc_log_level_t", "group__Log.html#ga2a574f003da6440aa63faaaf9dc6a906", [
      [ "ACC_LOG_LEVEL_ERROR", "group__Log.html#gga2a574f003da6440aa63faaaf9dc6a906a4d3bfb21ceea033ad27e5713dca4cf38", null ],
      [ "ACC_LOG_LEVEL_WARNING", "group__Log.html#gga2a574f003da6440aa63faaaf9dc6a906a6d7c13a9dae368a1ccc5d46774631ac7", null ],
      [ "ACC_LOG_LEVEL_INFO", "group__Log.html#gga2a574f003da6440aa63faaaf9dc6a906a041f0b15b66773dd5ca02e3a5dff5278", null ],
      [ "ACC_LOG_LEVEL_VERBOSE", "group__Log.html#gga2a574f003da6440aa63faaaf9dc6a906a3d38353a57c62d4ee3d8553ab4e4cb71", null ],
      [ "ACC_LOG_LEVEL_DEBUG", "group__Log.html#gga2a574f003da6440aa63faaaf9dc6a906af804954572982b7789f6d47e9c347b93", null ]
    ] ]
];