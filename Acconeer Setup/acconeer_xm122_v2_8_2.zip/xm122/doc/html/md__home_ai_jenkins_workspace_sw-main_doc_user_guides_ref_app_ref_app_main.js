var md__home_ai_jenkins_workspace_sw_main_doc_user_guides_ref_app_ref_app_main =
[
    [ "Parking", "parking.html", [
      [ "Source Code", "parking.html#autotoc_md1", null ],
      [ "Description", "parking.html#autotoc_md2", null ],
      [ "Configuration", "parking.html#autotoc_md3", [
        [ "Bluetooth", "parking.html#autotoc_md4", null ]
      ] ],
      [ "Testing", "parking.html#autotoc_md5", [
        [ "Test setup", "parking.html#autotoc_md6", [
          [ "Real-life setup", "parking.html#autotoc_md7", null ],
          [ "Lab environment setup", "parking.html#autotoc_md8", null ]
        ] ],
        [ "Test execution", "parking.html#autotoc_md9", [
          [ "Outside testing", "parking.html#autotoc_md10", null ],
          [ "Long duration testing", "parking.html#autotoc_md11", null ],
          [ "Over temperature", "parking.html#autotoc_md12", null ]
        ] ],
        [ "Test results", "parking.html#autotoc_md13", null ]
      ] ],
      [ "Limitations", "parking.html#autotoc_md14", null ]
    ] ],
    [ "Smart Presence", "smart_presence.html", [
      [ "Source Code", "smart_presence.html#autotoc_md15", null ],
      [ "Description", "smart_presence.html#autotoc_md16", null ],
      [ "Configuration", "smart_presence.html#autotoc_md17", null ],
      [ "Testing", "smart_presence.html#autotoc_md18", [
        [ "Test Setup", "smart_presence.html#autotoc_md19", null ],
        [ "Test Execution", "smart_presence.html#autotoc_md20", null ],
        [ "Test Results", "smart_presence.html#autotoc_md21", null ]
      ] ]
    ] ],
    [ "Tank Level", "tank_level.html", [
      [ "Source Code", "tank_level.html#autotoc_md22", null ],
      [ "Description", "tank_level.html#autotoc_md23", null ],
      [ "Configuration", "tank_level.html#autotoc_md24", null ],
      [ "Testing", "tank_level.html#autotoc_md25", [
        [ "Test setup", "tank_level.html#autotoc_md26", null ],
        [ "Test execution", "tank_level.html#autotoc_md27", null ],
        [ "Test results", "tank_level.html#autotoc_md28", [
          [ "Result", "tank_level.html#autotoc_md29", null ]
        ] ]
      ] ],
      [ "Limitations", "tank_level.html#autotoc_md30", null ]
    ] ]
];