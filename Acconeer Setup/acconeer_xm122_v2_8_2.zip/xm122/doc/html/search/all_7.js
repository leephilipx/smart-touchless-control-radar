var searchData=
[
  ['gain_5fstep_752',['GAIN_STEP',['../ref__app__tank__level_8c.html#a4f9113da4b3f6c00b0a632890cdc7e61',1,'ref_app_tank_level.c']]],
  ['generic_20service_20api_753',['Generic Service API',['../group__Generic.html',1,'']]],
  ['get_5freference_5ffrequency_754',['get_reference_frequency',['../structacc__rss__integration__sensor__device__t.html#a57c8db10bc444bb876bc357ac57dcf3c',1,'acc_rss_integration_sensor_device_t']]],
  ['get_5fservice_5ftype_755',['get_service_type',['../example__low__power_8c.html#a13e5a9afa14fdfca54a92adb6980af18',1,'example_low_power.c']]],
  ['gettime_756',['gettime',['../structacc__rss__integration__os__primitives__t.html#a8c6e9f7b685ab4fb2e839891cdfec069',1,'acc_rss_integration_os_primitives_t']]],
  ['gpio_5finit_757',['gpio_init',['../acc__hal__integration__xm122_8c.html#a599b41df634258a4002f46cfd8ce40bd',1,'acc_hal_integration_xm122.c']]],
  ['gpiote_5fconfig_5fdebug_5fcolor_758',['GPIOTE_CONFIG_DEBUG_COLOR',['../sdk__config_8h.html#a1f674ccb8bcfa05d04112233535794bc',1,'sdk_config.h']]],
  ['gpiote_5fconfig_5finfo_5fcolor_759',['GPIOTE_CONFIG_INFO_COLOR',['../sdk__config_8h.html#a14dca8330324745244642073be2cc2f2',1,'sdk_config.h']]],
  ['gpiote_5fconfig_5firq_5fpriority_760',['GPIOTE_CONFIG_IRQ_PRIORITY',['../sdk__config_8h.html#aaae1c471c65a25b8463a625635d5e01d',1,'sdk_config.h']]],
  ['gpiote_5fconfig_5flog_5fenabled_761',['GPIOTE_CONFIG_LOG_ENABLED',['../sdk__config_8h.html#a148040918f2cef8413e41fd9e2b6cbf2',1,'sdk_config.h']]],
  ['gpiote_5fconfig_5flog_5flevel_762',['GPIOTE_CONFIG_LOG_LEVEL',['../sdk__config_8h.html#adf4460fb81da6c955e00c9eb074c77bd',1,'sdk_config.h']]],
  ['gpiote_5fconfig_5fnum_5fof_5flow_5fpower_5fevents_763',['GPIOTE_CONFIG_NUM_OF_LOW_POWER_EVENTS',['../sdk__config_8h.html#aad94a499c1b92e05f0a7b645b5295d7f',1,'sdk_config.h']]],
  ['gpiote_5fenabled_764',['GPIOTE_ENABLED',['../sdk__config_8h.html#aedd7ac5f91ad5c239613a6552cde8eac',1,'sdk_config.h']]]
];
