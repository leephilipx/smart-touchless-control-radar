var searchData=
[
  ['vin_5fadc_5fen_5fdelay_5fus_1902',['VIN_ADC_EN_DELAY_US',['../acc__battery__info__xm122_8c.html#acb51222689052c097982e70f25ba12b3',1,'acc_battery_info_xm122.c']]],
  ['vin_5fadc_5fen_5fpin_1903',['VIN_ADC_EN_Pin',['../board__xm122_8h.html#aa63f57ff25218085c53976f52f8c84f3',1,'board_xm122.h']]],
  ['vin_5fadc_5fpin_1904',['VIN_ADC_Pin',['../board__xm122_8h.html#af884fb00ab312ebad7a828219b4dc8a5',1,'board_xm122.h']]],
  ['vprintf_1905',['vprintf',['../printf_8h.html#a275497dfccfba8ca97e73865fd2b083b',1,'printf.h']]],
  ['vprintf_5f_1906',['vprintf_',['../printf_8h.html#aa199d9388f8dcddcda1a0451315cae89',1,'vprintf_(const char *format, va_list va):&#160;printf.c'],['../printf_8c.html#aa199d9388f8dcddcda1a0451315cae89',1,'vprintf_(const char *format, va_list va):&#160;printf.c']]],
  ['vsnprintf_1907',['vsnprintf',['../printf_8h.html#a00ba2ca988495904efc418acbf0627d7',1,'printf.h']]],
  ['vsnprintf_5f_1908',['vsnprintf_',['../printf_8h.html#af37254f8c6a2d9d51e82c85fd666f88e',1,'vsnprintf_(char *buffer, size_t count, const char *format, va_list va):&#160;printf.c'],['../printf_8c.html#af37254f8c6a2d9d51e82c85fd666f88e',1,'vsnprintf_(char *buffer, size_t count, const char *format, va_list va):&#160;printf.c']]]
];
