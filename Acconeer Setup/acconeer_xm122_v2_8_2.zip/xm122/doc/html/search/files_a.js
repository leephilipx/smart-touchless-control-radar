var searchData=
[
  ['sdk_5fconfig_2eh_2004',['sdk_config.h',['../sdk__config_8h.html',1,'']]],
  ['smart_5fpresence_2emd_2005',['smart_presence.md',['../smart__presence_8md.html',1,'']]],
  ['sparse_2emd_2006',['sparse.md',['../sparse_8md.html',1,'']]]
];
