var searchData=
[
  ['record_5fbackground_2313',['record_background',['../example__detector__distance__recorded_8c.html#a545ceeb81dcfe1d8ab52cba40ae5d1ae',1,'record_background(acc_detector_distance_configuration_t distance_configuration):&#160;example_detector_distance_recorded.c'],['../ref__app__tank__level_8c.html#a1b38346b79b3e4b2bbb599743176b552',1,'record_background(acc_detector_distance_handle_t *distance_handle, acc_detector_distance_configuration_t distance_configuration, float *range_gain, uint16_t *background, uint16_t background_length):&#160;ref_app_tank_level.c']]],
  ['record_5fbackgrounds_2314',['record_backgrounds',['../ref__app__tank__level_8c.html#ab1a6c6e2c86b981a980905e1068357e9',1,'ref_app_tank_level.c']]],
  ['rtc_5fenable_2315',['rtc_enable',['../acc__integration__nordic_8c.html#a851562c4da44c0aca25cefe9e9311d04',1,'acc_integration_nordic.c']]],
  ['rtc_5fhandler_2316',['rtc_handler',['../acc__integration__nordic_8c.html#af4b5abde94acbb03fea592283ebd9855',1,'acc_integration_nordic.c']]],
  ['rtc_5fset_5fnext_5fwakeup_5ftime_2317',['rtc_set_next_wakeup_time',['../acc__integration__nordic_8c.html#a48e9cd0b38c7cce54cb81110224d7b29',1,'acc_integration_nordic.c']]]
];
