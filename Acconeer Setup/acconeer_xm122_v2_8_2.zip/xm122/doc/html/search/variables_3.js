var searchData=
[
  ['close_5fbackground_2341',['close_background',['../ref__app__tank__level_8c.html#a666898adebb5593c5728f9edc565dcbb',1,'ref_app_tank_level.c']]],
  ['close_5fbackground_5flength_2342',['close_background_length',['../ref__app__tank__level_8c.html#a181d2da361d26782e649040b3f12c742',1,'ref_app_tank_level.c']]],
  ['close_5frange_5fgain_2343',['close_range_gain',['../ref__app__tank__level_8c.html#a637108f286868074a553e2d9a249ed30',1,'ref_app_tank_level.c']]],
  ['closest_5fdetection_5fm_2344',['closest_detection_m',['../structacc__detector__distance__result__info__t.html#a1160e2d9b04fd3054d5013d91d1bdcb9',1,'acc_detector_distance_result_info_t']]]
];
