var searchData=
[
  ['calibrate_5fadc_2280',['calibrate_adc',['../acc__battery__info__xm122_8c.html#ad51883debed250dd89b7637c5b53d019',1,'acc_battery_info_xm122.c']]],
  ['configure_5fclose_5frange_2281',['configure_close_range',['../ref__app__tank__level_8c.html#ae821f2d84bfcdb3ca35378bf41ef1950',1,'ref_app_tank_level.c']]],
  ['configure_5ffar_5frange_2282',['configure_far_range',['../ref__app__tank__level_8c.html#a5807d4882e66cce1a91da0b8c18cd6f1',1,'ref_app_tank_level.c']]],
  ['configure_5fmid_5frange_2283',['configure_mid_range',['../ref__app__tank__level_8c.html#acaebea35185174840f231ed7ce86ef59',1,'ref_app_tank_level.c']]],
  ['configure_5fservice_2284',['configure_service',['../ref__app__parking_8c.html#a5178e8d7e4d723a474a10cc79fca3424',1,'ref_app_parking.c']]],
  ['create_5fenvelope_5fservice_2285',['create_envelope_service',['../example__low__power_8c.html#ab0bf2d5bf282d46a1866e4e4c51cafbb',1,'example_low_power.c']]],
  ['create_5fservice_2286',['create_service',['../example__low__power_8c.html#a28e2524924495dc50ced24a83274f041',1,'example_low_power.c']]],
  ['create_5fsparse_5fservice_2287',['create_sparse_service',['../example__low__power_8c.html#a1abd3921345022ebff4d2a5326f3f033',1,'example_low_power.c']]]
];
