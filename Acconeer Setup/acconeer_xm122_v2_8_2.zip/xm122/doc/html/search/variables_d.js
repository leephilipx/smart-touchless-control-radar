var searchData=
[
  ['periodic_5fsleep_5ftime_5fms_2384',['periodic_sleep_time_ms',['../acc__integration__nordic_8c.html#a9f6944b4a9e397c6e8e5d3fb22352a7f',1,'acc_integration_nordic.c']]],
  ['position_2385',['position',['../structprint__buffer__t.html#aa5acf92addfb60ec0f73c9c4f926f74b',1,'print_buffer_t']]],
  ['power_5foff_2386',['power_off',['../structacc__rss__integration__sensor__device__t.html#a78f841c9ca2b7516ae7ea85fa21d76b6',1,'acc_rss_integration_sensor_device_t']]],
  ['power_5fon_2387',['power_on',['../structacc__rss__integration__sensor__device__t.html#a646d7a7e1ab2ca6d2d29c9e6b728ab95',1,'acc_rss_integration_sensor_device_t']]],
  ['presence_5fdetected_2388',['presence_detected',['../structacc__detector__presence__result__t.html#a0cba70bf4b4b25e6a5a5f2531c6d2b24',1,'acc_detector_presence_result_t']]],
  ['presence_5fdistance_2389',['presence_distance',['../structacc__detector__presence__result__t.html#a343b878eb3c9fc86a615197133907a85',1,'acc_detector_presence_result_t']]],
  ['presence_5fscore_2390',['presence_score',['../structacc__detector__presence__result__t.html#a730af2ac4c5e883dbdfa108c1bf9629b',1,'acc_detector_presence_result_t']]],
  ['properties_2391',['properties',['../structacc__hal__t.html#a1c1672f8f6a5600ab856076384328f0c',1,'acc_hal_t']]],
  ['proximity_5fpower_2392',['proximity_power',['../structacc__service__iq__result__info__t.html#a5e6678395569094129be7ff853a07d30',1,'acc_service_iq_result_info_t']]]
];
