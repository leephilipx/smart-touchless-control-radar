var searchData=
[
  ['service_5fid_5fenvelope_2483',['SERVICE_ID_ENVELOPE',['../example__low__power_8c.html#a4c48cd22c9787f3a81d5726add3115f3a836ecae92834a75cffe72f272bbfc8c7',1,'example_low_power.c']]],
  ['service_5fid_5fsparse_2484',['SERVICE_ID_SPARSE',['../example__low__power_8c.html#a4c48cd22c9787f3a81d5726add3115f3a6b8b20dabf3f9e8b3275b9635638b9b7',1,'example_low_power.c']]],
  ['service_5fid_5funknown_2485',['SERVICE_ID_UNKNOWN',['../example__low__power_8c.html#a4c48cd22c9787f3a81d5726add3115f3a575d98b5ded20eae1939e70d97843517',1,'example_low_power.c']]]
];
