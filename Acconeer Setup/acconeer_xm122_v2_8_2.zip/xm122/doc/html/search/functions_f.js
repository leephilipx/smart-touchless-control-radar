var searchData=
[
  ['vprintf_5f_2328',['vprintf_',['../printf_8h.html#aa199d9388f8dcddcda1a0451315cae89',1,'vprintf_(const char *format, va_list va):&#160;printf.c'],['../printf_8c.html#aa199d9388f8dcddcda1a0451315cae89',1,'vprintf_(const char *format, va_list va):&#160;printf.c']]],
  ['vsnprintf_5f_2329',['vsnprintf_',['../printf_8h.html#af37254f8c6a2d9d51e82c85fd666f88e',1,'vsnprintf_(char *buffer, size_t count, const char *format, va_list va):&#160;printf.c'],['../printf_8c.html#af37254f8c6a2d9d51e82c85fd666f88e',1,'vsnprintf_(char *buffer, size_t count, const char *format, va_list va):&#160;printf.c']]]
];
