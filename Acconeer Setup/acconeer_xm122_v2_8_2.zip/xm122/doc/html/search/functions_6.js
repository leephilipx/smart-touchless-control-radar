var searchData=
[
  ['get_5fservice_5ftype_2295',['get_service_type',['../example__low__power_8c.html#a13e5a9afa14fdfca54a92adb6980af18',1,'example_low_power.c']]],
  ['gpio_5finit_2296',['gpio_init',['../acc__hal__integration__xm122_8c.html#a599b41df634258a4002f46cfd8ce40bd',1,'acc_hal_integration_xm122.c']]]
];
