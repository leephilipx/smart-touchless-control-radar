var searchData=
[
  ['sensor_5fcalibration_2318',['sensor_calibration',['../ref__app__parking_8c.html#a5acdfc16086f597dd606991d138675ee',1,'sensor_calibration(void):&#160;ref_app_parking.c'],['../ref__app__tank__level_8c.html#a5acdfc16086f597dd606991d138675ee',1,'sensor_calibration(void):&#160;ref_app_tank_level.c']]],
  ['service_5frecreate_2319',['service_recreate',['../ref__app__parking_8c.html#ac8a9800187b215844b3263db51cc0b7c',1,'ref_app_parking.c']]],
  ['set_5fdefault_5fconfiguration_2320',['set_default_configuration',['../ref__app__smart__presence_8c.html#a717617f45e73cadc0809faac8970445d',1,'ref_app_smart_presence.c']]],
  ['snprintf_5f_2321',['snprintf_',['../printf_8h.html#a5b16fca837f5301cb0c01fa668f044f4',1,'snprintf_(char *buffer, size_t count, const char *format,...):&#160;printf.c'],['../printf_8c.html#a5b16fca837f5301cb0c01fa668f044f4',1,'snprintf_(char *buffer, size_t count, const char *format,...):&#160;printf.c']]],
  ['spi_5finit_2322',['spi_init',['../acc__hal__integration__xm122_8c.html#a12ef129b49447deb66b091e58a805e75',1,'acc_hal_integration_xm122.c']]],
  ['spim_5fevent_5fhandler_2323',['spim_event_handler',['../acc__hal__integration__xm122_8c.html#a2894a33f3f5f6fdcf878c4f9dcf73a60',1,'acc_hal_integration_xm122.c']]],
  ['sprintf_5f_2324',['sprintf_',['../printf_8h.html#a989410555ef35cd646c15d51e649faaa',1,'sprintf_(char *buffer, const char *format,...):&#160;printf.c'],['../printf_8c.html#a989410555ef35cd646c15d51e649faaa',1,'sprintf_(char *buffer, const char *format,...):&#160;printf.c']]]
];
