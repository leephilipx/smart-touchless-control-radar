var searchData=
[
  ['get_5freference_5ffrequency_2353',['get_reference_frequency',['../structacc__rss__integration__sensor__device__t.html#a57c8db10bc444bb876bc357ac57dcf3c',1,'acc_rss_integration_sensor_device_t']]],
  ['gettime_2354',['gettime',['../structacc__rss__integration__os__primitives__t.html#a8c6e9f7b685ab4fb2e839891cdfec069',1,'acc_rss_integration_os_primitives_t']]]
];
