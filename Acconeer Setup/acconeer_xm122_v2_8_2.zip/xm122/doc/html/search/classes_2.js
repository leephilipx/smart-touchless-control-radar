var searchData=
[
  ['print_5fbuffer_5ft_1947',['print_buffer_t',['../structprint__buffer__t.html',1,'']]]
];
