var searchData=
[
  ['vin_5fadc_5fen_5fdelay_5fus_3799',['VIN_ADC_EN_DELAY_US',['../acc__battery__info__xm122_8c.html#acb51222689052c097982e70f25ba12b3',1,'acc_battery_info_xm122.c']]],
  ['vin_5fadc_5fen_5fpin_3800',['VIN_ADC_EN_Pin',['../board__xm122_8h.html#aa63f57ff25218085c53976f52f8c84f3',1,'board_xm122.h']]],
  ['vin_5fadc_5fpin_3801',['VIN_ADC_Pin',['../board__xm122_8h.html#af884fb00ab312ebad7a828219b4dc8a5',1,'board_xm122.h']]],
  ['vprintf_3802',['vprintf',['../printf_8h.html#a275497dfccfba8ca97e73865fd2b083b',1,'printf.h']]],
  ['vsnprintf_3803',['vsnprintf',['../printf_8h.html#a00ba2ca988495904efc418acbf0627d7',1,'printf.h']]]
];
