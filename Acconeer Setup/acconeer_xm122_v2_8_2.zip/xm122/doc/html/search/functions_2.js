var searchData=
[
  ['ble_5fevt_5fhandler_2278',['ble_evt_handler',['../acc__bluetooth__beacon__xm122_8c.html#af79fad11603ce86f991e529e023dc564',1,'acc_bluetooth_beacon_xm122.c']]],
  ['ble_5fstack_5finit_2279',['ble_stack_init',['../acc__bluetooth__beacon__xm122_8c.html#aa06a7a39e83ec4cf3553f4ed6ba6323a',1,'acc_bluetooth_beacon_xm122.c']]]
];
