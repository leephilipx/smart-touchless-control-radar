var searchData=
[
  ['_5f_5fheapbase_2330',['__HeapBase',['../main_8c.html#a0d316bd4ef5a593400435781c6c68b1c',1,'main.c']]],
  ['_5f_5fheaplimit_2331',['__HeapLimit',['../main_8c.html#a4ee99e498d365d260fd876fab3a347c1',1,'main.c']]]
];
