var searchData=
[
  ['smart_20presence_3846',['Smart Presence',['../smart_presence.html',1,'md__home_ai_jenkins_workspace_sw-main_doc_user_guides_ref_app_ref_app_main']]],
  ['sparse_20service_3847',['Sparse Service',['../sparse.html',1,'md__home_ai_jenkins_workspace_sw-main_doc_user_guides_rss_user_guide_main']]]
];
