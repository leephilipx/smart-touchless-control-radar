var searchData=
[
  ['fctprintf_2293',['fctprintf',['../printf_8h.html#a16cdc6ff34afc2122ae164d4ee3a8c50',1,'fctprintf(void(*out)(char character, void *arg), void *arg, const char *format,...):&#160;printf.c'],['../printf_8c.html#a16cdc6ff34afc2122ae164d4ee3a8c50',1,'fctprintf(void(*out)(char character, void *arg), void *arg, const char *format,...):&#160;printf.c']]],
  ['fctvprintf_2294',['fctvprintf',['../printf_8h.html#ac699a9a625dc2641d66ff8d7a29ea223',1,'fctvprintf(void(*out)(char character, void *arg), void *arg, const char *format, va_list va):&#160;printf.c'],['../printf_8c.html#ac699a9a625dc2641d66ff8d7a29ea223',1,'fctvprintf(void(*out)(char character, void *arg), void *arg, const char *format, va_list va):&#160;printf.c']]]
];
