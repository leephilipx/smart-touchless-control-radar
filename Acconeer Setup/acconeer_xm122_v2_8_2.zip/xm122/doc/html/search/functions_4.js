var searchData=
[
  ['execute_5fenvelope_5fservice_2288',['execute_envelope_service',['../example__low__power_8c.html#a21ee4e1acb230befd4d244386b6f7b2a',1,'example_low_power.c']]],
  ['execute_5fmovement_5ftracking_2289',['execute_movement_tracking',['../ref__app__smart__presence_8c.html#a09a59a5d0c9a2dcecdbb7e94dacdd7e6',1,'ref_app_smart_presence.c']]],
  ['execute_5fservice_2290',['execute_service',['../example__low__power_8c.html#ab42dad66a79bc1eac5ce4e9fa5286a6f',1,'example_low_power.c']]],
  ['execute_5fsparse_5fservice_2291',['execute_sparse_service',['../example__low__power_8c.html#a5a4e41da2b98e6e1062c1735509efdeb',1,'example_low_power.c']]],
  ['execute_5fwakeup_2292',['execute_wakeup',['../ref__app__smart__presence_8c.html#ad38e1cf1ea7fa58f6d2aa01e6d4ed21e',1,'ref_app_smart_presence.c']]]
];
