var searchData=
[
  ['log_20integration_3828',['Log Integration',['../group__Log.html',1,'']]]
];
