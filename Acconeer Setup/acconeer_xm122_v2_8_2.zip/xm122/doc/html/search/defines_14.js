var searchData=
[
  ['xm122_5fi2c_5fdevice_5fid_3816',['XM122_I2C_DEVICE_ID',['../board__xm122_8h.html#a7d2ea91c2aa2004695d4d317ddf116b7',1,'board_xm122.h']]]
];
