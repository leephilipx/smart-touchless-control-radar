// Copyright (c) Acconeer AB, 2021
// All rights reserved
// This file is subject to the terms and conditions defined in the file
// 'LICENSES/license_acconeer.txt', (BSD 3-Clause License) which is part
// of this source code package.
#include "acc_uart_same70.h"
#include "chip.h"


uint8_t mop_uart_ports[UART_IFACE_COUNT] = {};

const acc_uart_same70_config_t acc_uart_same70_config =
{
	.debug_uart_port          = 0,
	.debug_uart_port_baudrate = 115200,
	.enable_uart_debug        = true,
	.mop_uart_count           = 0,
	.mop_uart_ports           = mop_uart_ports,
};
