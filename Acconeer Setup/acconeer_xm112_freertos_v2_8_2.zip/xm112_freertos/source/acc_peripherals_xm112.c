// Copyright (c) Acconeer AB, 2021
// All rights reserved
// This file is subject to the terms and conditions defined in the file
// 'LICENSES/license_acconeer.txt', (BSD 3-Clause License) which is part
// of this source code package.

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#include "acc_i2c_same70.h"
#include "acc_integration.h"

#include "acc_peripherals_xm112.h"


#define XM112_I2C_EEPROM_DEVICE_ID      0x51
#define XM112_I2C_TEMPERATURE_DEVICE_ID 0x48

#define DS7505_REG_TEMPERATURE    0x00  /**< temperature reading */
#define DS7505_REG_CONFIGURATION  0x01  /**< device configuration register */
#define DS7505_REG_T_HYST         0x02  /**< set temperature hysteresis */
#define DS7505_REG_T_OS           0x03  /**< set O.S. output temperature threshold */
#define DS7505_CMD_RECALL_DATA    0xb8  /**< load internal EEPROM data into SRAM shadow registers */
#define DS7505_CMD_COPY_DATA      0x48  /**< copy from SRAM shadow registers into internal EEPROM */
#define DS7505_CMD_SOFTWARE_RESET 0x54  /**< perform a software power on reset */

#define M24128_PAGE_SIZE 64

#define MIN(a, b) ((a) < (b)) ? (a) : (b)


static acc_i2c_same70_handle_t i2c_handle = NULL;


//-----------------------------
// Private definitions
//-----------------------------


static bool acc_peripherals_xm112_temperature_init(void)
{
	static uint8_t i2c_buffer;

	// errors are ignored since the DS7505 will not ACK the reset command
	acc_i2c_same70_write_to_address_8(i2c_handle, XM112_I2C_TEMPERATURE_DEVICE_ID, DS7505_CMD_SOFTWARE_RESET, NULL, 0);

	i2c_buffer = 0x60;  /* R1..R0 = 12 bit resolution, TM = comparator mode, SD = active conversion and thermostat operation */

	if (!acc_i2c_same70_write_to_address_8(i2c_handle, XM112_I2C_TEMPERATURE_DEVICE_ID, DS7505_REG_CONFIGURATION,
	                                       &i2c_buffer, 1))
	{
		return false;
	}

	return true;
}


//-----------------------------
// Public definitions
//-----------------------------


bool acc_peripherals_xm112_init(void)
{
	acc_i2c_same70_configuration_t i2c_configuration;

	i2c_configuration.bus                   = 2;
	i2c_configuration.master                = true;
	i2c_configuration.mode.master.frequency = 100000;

	i2c_handle = acc_i2c_same70_create(i2c_configuration);
	if (NULL == i2c_handle)
	{
		printf("Unable to create I2C\n");
		return false;
	}

	return acc_peripherals_xm112_temperature_init();
}


void acc_peripherals_xm112_deinit(void)
{
	if (NULL != i2c_handle)
	{
		acc_i2c_same70_destroy(&i2c_handle);
	}
}


bool acc_peripherals_xm112_temperature_read(float *temperature)
{
	uint8_t i2c_buffer[2];

	if (!acc_i2c_same70_read_from_address_8(i2c_handle, XM112_I2C_TEMPERATURE_DEVICE_ID, DS7505_REG_TEMPERATURE, i2c_buffer, 2))
	{
		return false;
	}

	uint16_t temp = ((uint16_t)i2c_buffer[0] << 8) + i2c_buffer[1];
	*temperature = (float)*(int16_t *)&temp / 256.0f;

	return true;
}


bool acc_peripherals_xm112_eeprom_write(uint32_t address, const void *buffer, size_t size)
{
	bool          success = true;
	const uint8_t *data   = buffer;

	while (size > 0)
	{
		size_t chunk_size = MIN(size, M24128_PAGE_SIZE - (address % M24128_PAGE_SIZE));

		if (!acc_i2c_same70_write_to_address_16(i2c_handle,
		                                        XM112_I2C_EEPROM_DEVICE_ID,
		                                        address, data, chunk_size))
		{
			printf("Failed to write to memory.\n");
			success = false;
			break;
		}

		uint8_t dummy;

		/* According to datasheet, page 30: https://www.st.com/resource/en/datasheet/m24128-df.pdf
		 * max write delay is 5ms (tw), we could also poll, but currently there is a poll timeout in
		 * the driver of 100ms which will give a slower result.
		 */
		acc_integration_sleep_ms(5);

		if (!acc_i2c_same70_read_from_address_16(i2c_handle,
		                                         XM112_I2C_EEPROM_DEVICE_ID,
		                                         address, &dummy, 1))
		{
			printf("Write action did not complete in time.\n");
			success = false;
			break;
		}

		size    -= chunk_size;
		address += chunk_size;
		data    += chunk_size;
	}
	return success;
}


bool acc_peripherals_xm112_eeprom_read(uint32_t address, void *buffer, size_t size)
{
	if (!acc_i2c_same70_read_from_address_16(i2c_handle, XM112_I2C_EEPROM_DEVICE_ID, address, buffer, size))
	{
		return false;
	}

	return true;
}
