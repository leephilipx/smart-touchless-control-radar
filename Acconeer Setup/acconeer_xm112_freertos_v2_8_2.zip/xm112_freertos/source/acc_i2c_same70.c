// Copyright (c) Acconeer AB, 2018-2021
// All rights reserved
// This file is subject to the terms and conditions defined in the file
// 'LICENSES/license_acconeer.txt', (BSD 3-Clause License) which is part
// of this source code package.

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include "acc_i2c_same70.h"

#include "bus.h"
#include "pio.h"
#include "twid.h"

/**
 * @brief I2C for same70q21
 */

#define I2C_PERIPHERAL_COUNT (3)
#define I2C_TIMEOUT          (15000u)
#define I2C_FAST_MODE_SPEED  (400000u)

typedef struct
{
	struct _pin pins[2];
} i2c_peripheral_t;


static const i2c_peripheral_t i2c_peripheral[I2C_PERIPHERAL_COUNT] =
{
	{
		.pins = PINS_TWI0,
	},
	{
		.pins = PINS_TWI1,
	},
	{
		.pins = PINS_TWI2,
	}
};

typedef struct acc_i2c_same70_handle
{
	const struct _pin                   *pins;
	bool                                peripheral_enabled;
	acc_i2c_same70_slave_isr_callback_t slave_access_isr;
	struct _twi_slave_desc              slave_desc;
	struct _twi_desc                    master_desc;
	struct _twi_slave_ops               slave_ops;
} acc_i2c_same70_handle_internal_t;


//-----------------------------
// Private declarations
//-----------------------------

static bool i2c_generic_read(acc_i2c_same70_handle_t handle, uint8_t device_id, uint32_t address, uint_fast8_t address_size,
                             uint8_t *buffer, size_t buffer_size);


static bool i2c_generic_write(acc_i2c_same70_handle_t handle, uint8_t device_id, uint32_t address, uint_fast8_t address_size,
                              const uint8_t *buffer, size_t buffer_size);


static void i2c_on_start(acc_i2c_same70_handle_internal_t *context);


static void i2c_on_stop(acc_i2c_same70_handle_internal_t *context);


static void i2c_on_write(acc_i2c_same70_handle_internal_t *context, uint8_t data);


static uint8_t i2c_on_read(acc_i2c_same70_handle_internal_t *context);


static void i2c_0_on_start(void);


static void i2c_0_on_stop(void);


static void i2c_0_on_write(uint8_t data);


static uint8_t i2c_0_on_read(void);


static void i2c_1_on_start(void);


static void i2c_1_on_stop(void);


static void i2c_1_on_write(uint8_t data);


static uint8_t i2c_1_on_read(void);


static void i2c_2_on_start(void);


static void i2c_2_on_stop(void);


static void i2c_2_on_write(uint8_t data);


static uint8_t i2c_2_on_read(void);


static acc_i2c_same70_handle_internal_t i2c_context[I2C_PERIPHERAL_COUNT] =
{
	{
		.peripheral_enabled        = false,
		.slave_access_isr          = {0, },
		.slave_desc.twi            = TWI0,
		.slave_ops.on_start        = i2c_0_on_start,
		.slave_ops.on_stop         = i2c_0_on_stop,
		.slave_ops.on_read         = i2c_0_on_read,
		.slave_ops.on_write        = i2c_0_on_write,
		.master_desc.addr          = TWI0,
		.master_desc.transfer_mode = BUS_TRANSFER_MODE_POLLING,
		.pins                      = i2c_peripheral[0].pins,
	},
	{
		.peripheral_enabled        = false,
		.slave_access_isr          = {0, },
		.slave_desc.twi            = TWI1,
		.slave_ops.on_start        = i2c_1_on_start,
		.slave_ops.on_stop         = i2c_1_on_stop,
		.slave_ops.on_read         = i2c_1_on_read,
		.slave_ops.on_write        = i2c_1_on_write,
		.master_desc.addr          = TWI1,
		.master_desc.transfer_mode = BUS_TRANSFER_MODE_POLLING,
		.pins                      = i2c_peripheral[1].pins,
	},
	{
		.peripheral_enabled        = false,
		.slave_access_isr          = {0, },
		.slave_desc.twi            = TWI2,
		.slave_ops.on_start        = i2c_2_on_start,
		.slave_ops.on_stop         = i2c_2_on_stop,
		.slave_ops.on_read         = i2c_2_on_read,
		.slave_ops.on_write        = i2c_2_on_write,
		.master_desc.addr          = TWI2,
		.master_desc.transfer_mode = BUS_TRANSFER_MODE_POLLING,
		.pins                      = i2c_peripheral[2].pins,
	}
};


//-----------------------------
// Public definitions
//-----------------------------


acc_i2c_same70_handle_t acc_i2c_same70_create(acc_i2c_same70_configuration_t configuration)
{
	acc_i2c_same70_handle_t handle = NULL;

	if (configuration.bus < I2C_PERIPHERAL_COUNT)
	{
		acc_i2c_same70_handle_internal_t *i2c = &i2c_context[configuration.bus];
		pio_configure(i2c->pins, 2);

		if (configuration.master)
		{
			i2c->master_desc.freq = configuration.mode.master.frequency;
			int err = twid_configure(&i2c->master_desc);

			if (err != 0)
			{
				return NULL;
			}
		}
		else
		{
			i2c->slave_desc.addr = configuration.mode.slave.address;
			int err = twid_slave_configure(&i2c->slave_desc, &i2c->slave_ops);

			if (err != 0)
			{
				printf("Failed to create I2C slave %d\n", err);

				return NULL;
			}
		}

		handle = (acc_i2c_same70_handle_t)i2c;
	}

	return handle;
}


void acc_i2c_same70_destroy(acc_i2c_same70_handle_t *handle)
{
	*handle = NULL;
}


bool acc_i2c_same70_read_from_address_8(acc_i2c_same70_handle_t handle, uint8_t device_id, uint8_t address, uint8_t *buffer,
                                        size_t buffer_size)
{
	return i2c_generic_read(handle, device_id, address, 1, buffer, buffer_size);
}


bool acc_i2c_same70_read_from_address_16(acc_i2c_same70_handle_t handle, uint8_t device_id, uint16_t address, uint8_t *buffer,
                                         size_t buffer_size)
{
	return i2c_generic_read(handle, device_id, address, 2, buffer, buffer_size);
}


bool acc_i2c_same70_write_to_address_8(acc_i2c_same70_handle_t handle, uint8_t device_id, uint8_t address,
                                       const uint8_t *buffer, size_t buffer_size)
{
	return i2c_generic_write(handle, device_id, address, 1, buffer, buffer_size);
}


bool acc_i2c_same70_write_to_address_16(acc_i2c_same70_handle_t handle, uint8_t device_id, uint16_t address,
                                        const uint8_t *buffer, size_t buffer_size)
{
	return i2c_generic_write(handle, device_id, address, 2, buffer, buffer_size);
}


void acc_i2c_same70_slave_access_isr_register(acc_i2c_same70_handle_t handle, acc_i2c_same70_slave_isr_callback_t *isr)
{
	acc_i2c_same70_handle_internal_t *i2c = handle;

	i2c->slave_access_isr = *isr;
}


bool i2c_generic_read(acc_i2c_same70_handle_t handle,
                      uint8_t                 device_id,
                      uint32_t                address,
                      uint_fast8_t            address_size,
                      uint8_t                 *buffer,
                      size_t                  buffer_size)
{
	acc_i2c_same70_handle_internal_t *i2c = handle;

	i2c->master_desc.slave_addr = device_id;

	uint8_t        addr_buf[2];
	struct _buffer buf[2] =
	{
		{
			.data = addr_buf,
			.size = address_size,
			.attr = BUS_I2C_BUF_ATTR_START | BUS_BUF_ATTR_TX,
		},
		{
			.data = buffer,
			.size = buffer_size,
			.attr = BUS_I2C_BUF_ATTR_START | BUS_BUF_ATTR_RX | BUS_I2C_BUF_ATTR_STOP,
		},
	};

	if (address_size == 1)
	{
		addr_buf[0] = address & 0xff;
	}
	else
	{
		addr_buf[0] = address >> 8;
		addr_buf[1] = address & 0xff;
	}

	int err = twid_transfer(&i2c->master_desc, (struct _buffer *)&buf, 2, NULL);

	if (err != 0)
	{
		printf("I2C read error %d\n", err);
	}

	return err == 0;
}


bool i2c_generic_write(acc_i2c_same70_handle_t handle,
                       uint8_t                 device_id,
                       uint32_t                address,
                       uint_fast8_t            address_size,
                       const uint8_t           *buffer,
                       size_t                  buffer_size)
{
	acc_i2c_same70_handle_internal_t *i2c = handle;

	i2c->master_desc.slave_addr = device_id;

	uint8_t        addr_buf[2];
	struct _buffer buf[2] =
	{
		{
			.data = addr_buf,
			.size = address_size,
			.attr = BUS_I2C_BUF_ATTR_START | BUS_BUF_ATTR_TX,
		},
		{
			.data = (uint8_t *)buffer,
			.size = buffer_size,
			.attr = BUS_BUF_ATTR_TX | BUS_I2C_BUF_ATTR_STOP,
		},
	};

	if (address_size == 1)
	{
		addr_buf[0] = address & 0xff;
	}
	else
	{
		addr_buf[0] = address >> 8;
		addr_buf[1] = address & 0xff;
	}

	int err = twid_transfer(&i2c->master_desc, (struct _buffer *)&buf, 2, NULL);

	if (err != 0)
	{
		printf("I2C write error %d\n", err);
	}

	return err == 0;
}


void i2c_on_start(acc_i2c_same70_handle_internal_t *i2c)
{
	if (i2c->slave_access_isr.on_start != NULL)
	{
		i2c->slave_access_isr.on_start(i2c);
	}
}


void i2c_on_stop(acc_i2c_same70_handle_internal_t *i2c)
{
	if (i2c->slave_access_isr.on_stop != NULL)
	{
		i2c->slave_access_isr.on_stop(i2c);
	}
}


void i2c_on_write(acc_i2c_same70_handle_internal_t *i2c, uint8_t data)
{
	if (i2c->slave_access_isr.on_write != NULL)
	{
		i2c->slave_access_isr.on_write(i2c, data);
	}
}


uint8_t i2c_on_read(acc_i2c_same70_handle_internal_t *i2c)
{
	uint8_t data = 0xff;

	if (i2c->slave_access_isr.on_read != NULL)
	{
		data = i2c->slave_access_isr.on_read(i2c);
	}

	return data;
}


void i2c_0_on_start(void)
{
	i2c_on_start(&i2c_context[0]);
}


void i2c_0_on_stop(void)
{
	i2c_on_stop(&i2c_context[0]);
}


void i2c_0_on_write(uint8_t data)
{
	i2c_on_write(&i2c_context[0], data);
}


uint8_t i2c_0_on_read(void)
{
	return i2c_on_read(&i2c_context[0]);
}


void i2c_1_on_start(void)
{
	i2c_on_start(&i2c_context[1]);
}


void i2c_1_on_stop(void)
{
	i2c_on_stop(&i2c_context[1]);
}


void i2c_1_on_write(uint8_t data)
{
	i2c_on_write(&i2c_context[1], data);
}


uint8_t i2c_1_on_read(void)
{
	return i2c_on_read(&i2c_context[1]);
}


void i2c_2_on_start(void)
{
	i2c_on_start(&i2c_context[2]);
}


void i2c_2_on_stop(void)
{
	i2c_on_stop(&i2c_context[2]);
}


void i2c_2_on_write(uint8_t data)
{
	i2c_on_write(&i2c_context[2], data);
}


uint8_t i2c_2_on_read(void)
{
	return i2c_on_read(&i2c_context[2]);
}
