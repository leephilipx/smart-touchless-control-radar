// Copyright (c) Acconeer AB, 2018-2021
// All rights reserved
// This file is subject to the terms and conditions defined in the file
// 'LICENSES/license_acconeer.txt', (BSD 3-Clause License) which is part
// of this source code package.

#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "FreeRTOS.h"
#include "irq/nvic.h"
#include "rstc.h"
#include "samv71.h"

#include "acc_ms_system.h"

#include "acc_definitions.h"
#include "acc_gpio_same70.h"
#include "acc_hal_integration.h"
#include "acc_hal_integration_xm112.h"
#include "acc_integration.h"
#include "acc_log.h"
#include "acc_log_integration.h"
#include "acc_ms_system.h"
#include "acc_peripherals_xm112.h"
#include "acc_port.h"
#include "acc_spi_same70.h"
#include "acc_uart_same70.h"

/**
 * @brief The module name
 *
 * Must exist if acc_log.h is used.
 */
#define MODULE "acc_hal_integration_xm112"


/* Backup register 0..3 are cleared when waking up
 * on WKUP0 (PA0 = SENS_INT) or WKUP1 (=PA1 = NC),
 * so avoid them for now even if it is probably not relevant*/
#define GPBR_ERROR_COUNTER_REGISTER 4
#define GPBR_SERVICE_MODE_REGISTER  5
#define GPBR_SERVICE_MODE_VALUE     0xACC01CED


extern uint8_t acc_debug_uart_port;


#define XM11x_SENSOR_COUNT (1)

#define XM11x_SENSOR_REFERENCE_FREQUENCY (24000000)
#define XM11x_SPI_MASTER_BUS             (1)
#define XM11x_SPI_MASTER_BUF_SIZE        (1024)

#define XM11x_SENS_INT_PIN   0   // PA0
#define XM11x_SENS_EN_PIN    106 // PD10
#define XM11x_LED_PIN        67  // PC3
#define XM11x_MODULE_INT_PIN 66  // PC2
#define XM11x_PS_ENABLE_PIN  98  // PD2
#define XM11x_PWR_SIGNAL_PIN 30  // PA30

#define XM11x_GPIO_PINS 144


#define XM11x_GD_MAGIC_NUMBER (0xACC01337)


#define NVIC_IPR_REGISTER_COUNT 60

static acc_integration_semaphore_t uart_complete_semaphores[UART_IFACE_COUNT];

#define UART_TRANSFER_TIMEOUT 1000

#define SPI_MASTER_TRANSFER_TIMEOUT 1000


typedef struct
{
	bool     open;
	uint32_t baudrate;
	bool     use_as_debug;
} acc_hal_integration_xm112_uart_config_t;

typedef struct
{
	acc_hal_integration_xm112_uart_config_t uart_config[UART_IFACE_COUNT];
} acc_hal_integration_xm112_config_t;

static acc_hal_integration_xm112_config_t config;

/**
 * @brief The sensor SPI pins
 */
static acc_spi_same70_pin_config_t sensor_spi_config = PINS_SPI1_NPCS0;

static acc_spi_same70_handle_t     spi_master_handle;
static acc_integration_semaphore_t spi_master_transfer_complete_semaphore;
static acc_gpio_same70_t           gpios[XM11x_GPIO_PINS];

static bool sensor_active = false;

static acc_integration_semaphore_t isr_semaphore;

static acc_ms_sensor_interrupt_callback_t isr_callback;


bool acc_ms_system_is_sensor_interrupt_active(void)
{
	uint8_t level;

	acc_gpio_same70_read(XM11x_SENS_INT_PIN, &level);
	return level;
}


void acc_ms_system_register_sensor_interrupt_callback(acc_ms_sensor_interrupt_callback_t callback)
{
	isr_callback = callback;
}


static void isr_sensor(void)
{
	assert(isr_semaphore != NULL);
	acc_integration_semaphore_signal(isr_semaphore);
	if (isr_callback != NULL)
	{
		isr_callback();
	}
}


static bool setup_isr(void)
{
	isr_semaphore = acc_integration_semaphore_create();

	if (isr_semaphore == NULL)
	{
		return false;
	}

	if (!acc_gpio_same70_register_isr(XM11x_SENS_INT_PIN, ACC_GPIO_SAME70_EDGE_RISING, &isr_sensor))
	{
		return false;
	}

	return true;
}


static void set_led(bool enable);


static void acc_hal_integration_deinit(void);


static bool is_service_mode(void);


static void xm11x_wait_for_spi_transfer_complete(acc_spi_same70_handle_t dev_handle)
{
	if (dev_handle == spi_master_handle)
	{
		acc_integration_semaphore_wait(spi_master_transfer_complete_semaphore, SPI_MASTER_TRANSFER_TIMEOUT);
	}
}


static void xm11x_spi_transfer_complete_callback(acc_spi_same70_handle_t dev_handle)
{
	if (dev_handle == spi_master_handle)
	{
		assert(spi_master_transfer_complete_semaphore != NULL);
		acc_integration_semaphore_signal(spi_master_transfer_complete_semaphore);
	}
}


static void xm11x_wait_for_uart_transfer_complete(uint_fast8_t port)
{
	acc_integration_semaphore_wait(uart_complete_semaphores[port], UART_TRANSFER_TIMEOUT);
}


static void xm11x_uart_transfer_complete_callback(uint_fast8_t port)
{
	assert(uart_complete_semaphores[port] != NULL);
	acc_integration_semaphore_signal(uart_complete_semaphores[port]);
}


static bool gpio_init(void)
{
	acc_gpio_same70_register(XM11x_GPIO_PINS, gpios);
	acc_gpio_same70_init();
	set_led(false);

	acc_gpio_same70_set_initial_pull(XM11x_SENS_INT_PIN, 0);
	acc_gpio_same70_set_initial_pull(XM11x_SENS_EN_PIN, 0);
	acc_gpio_same70_set_initial_pull(XM11x_PS_ENABLE_PIN, 0);
	acc_gpio_same70_set_initial_pull(XM11x_PWR_SIGNAL_PIN, 0);

	if (!acc_gpio_same70_write(XM11x_SENS_EN_PIN, 0))
	{
		ACC_LOG_ERROR("Unable to deactivate SENS_EN");
		return false;
	}

	if (!acc_gpio_same70_write(XM11x_PS_ENABLE_PIN, 0))
	{
		ACC_LOG_ERROR("Unable to deactivate PS_ENABLE");
		return false;
	}

	if (!acc_gpio_same70_input(XM11x_SENS_INT_PIN))
	{
		ACC_LOG_ERROR("Unable to configure SENS_INT as input");
		return false;
	}

	if (!acc_gpio_same70_input(XM11x_MODULE_INT_PIN))
	{
		ACC_LOG_ERROR("Unable to deactivate module interrupt pin");
		return false;
	}

	if (!acc_gpio_same70_input(XM11x_PWR_SIGNAL_PIN))
	{
		ACC_LOG_ERROR("Unable to configure pwr_signal_pin as input");
		return false;
	}

	return true;
}


static bool uart_init(void)
{
	for (int i = 0; i < UART_IFACE_COUNT; i++)
	{
		if (config.uart_config[i].open)
		{
			uart_complete_semaphores[i] = acc_integration_semaphore_create();
			if (NULL == uart_complete_semaphores[i])
			{
				ACC_LOG_ERROR("Unable to create semaphore");
				return false;
			}

			acc_uart_same70_init(i, config.uart_config[i].baudrate, ACC_UART_SAME70_OPTIONS_ALT_PINS_1);
			if (config.uart_config[i].use_as_debug)
			{
				acc_debug_uart_port = i;
			}
		}
	}

	acc_uart_same70_register(xm11x_wait_for_uart_transfer_complete, xm11x_uart_transfer_complete_callback);

	return true;
}


static bool spi_init(void)
{
	spi_master_transfer_complete_semaphore = acc_integration_semaphore_create();
	if (NULL == spi_master_transfer_complete_semaphore)
	{
		ACC_LOG_ERROR("Unable to create semaphore");
		return false;
	}

	acc_spi_same70_register(xm11x_wait_for_spi_transfer_complete, xm11x_spi_transfer_complete_callback);

	acc_spi_same70_configuration_t master_configuration;

	master_configuration.bus           = XM11x_SPI_MASTER_BUS;
	master_configuration.configuration = &sensor_spi_config;
	master_configuration.device        = XM11x_SPI_CS;
	master_configuration.master        = true;
	master_configuration.speed         = XM11x_SPI_SPEED;
	master_configuration.buffer_size   = XM11x_SPI_MASTER_BUF_SIZE;

	spi_master_handle = acc_spi_same70_create(&master_configuration);
	if (NULL == spi_master_handle)
	{
		ACC_LOG_ERROR("Unable to create SPI master");
		return false;
	}

	return true;
}


static void acc_hal_integration_get_config(void)
{
	memset(&config, 0, sizeof(config));
	if (acc_uart_same70_config.enable_uart_debug)
	{
		config.uart_config[acc_uart_same70_config.debug_uart_port].open     = true;
		config.uart_config[acc_uart_same70_config.debug_uart_port].baudrate =
			acc_uart_same70_config.debug_uart_port_baudrate;
		config.uart_config[acc_uart_same70_config.debug_uart_port].use_as_debug = true;
	}

	for (uint8_t i = 0; i < acc_uart_same70_config.mop_uart_count; i++)
	{
		config.uart_config[acc_uart_same70_config.mop_uart_ports[i]].open     = true;
		config.uart_config[acc_uart_same70_config.mop_uart_ports[i]].baudrate = 115200;
	}
}


bool acc_hal_integration_xm112_init(void)
{
	acc_hal_integration_get_config();

	acc_integration_os_init();

	// Initialize interrupt priority for all external interrupts to
	// the most urgent priority allowed in FreeRTOS.
	uint32_t prioReg = (configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY << (8U - configPRIO_BITS));
	prioReg = (prioReg << 24) | (prioReg << 16) | (prioReg << 8) | prioReg;
	for (int i = 0; i < NVIC_IPR_REGISTER_COUNT; i++)
	{
		NVIC->NVIC_IPR[i] = prioReg;
	}

	if (!uart_init())
	{
		ACC_LOG_ERROR("Unable to initialize UART");
		acc_hal_integration_deinit();
		return false;
	}

	ACC_LOG_INFO("Error counter is now %" PRIu32, GPBR->SYS_GPBR[GPBR_ERROR_COUNTER_REGISTER]);

	if (!gpio_init())
	{
		ACC_LOG_ERROR("Unable to initialize GPIO");
		acc_hal_integration_deinit();
		return false;
	}

	if (!spi_init())
	{
		ACC_LOG_ERROR("Unable to initialize SPI");
		acc_hal_integration_deinit();
		return false;
	}

	if (!acc_peripherals_xm112_init())
	{
		ACC_LOG_ERROR("Unable to initiate peripherals");
		acc_hal_integration_deinit();
	}

	uint32_t magic_number = 0;

	if (acc_peripherals_xm112_eeprom_read(0, &magic_number, sizeof(magic_number)))
	{
		ACC_LOG_INFO("Magic number read: 0x%8" PRIx32, magic_number);

		if (magic_number != XM11x_GD_MAGIC_NUMBER)
		{
			ACC_LOG_INFO("Magic number not matched, unknown revision");
		}
	}
	else
	{
		ACC_LOG_ERROR("XM11x data could not be read");
		if (!is_service_mode())
		{
			acc_hal_integration_deinit();
			return false;
		}
	}

	if (!acc_port_init(XM11x_PWR_SIGNAL_PIN))
	{
		ACC_LOG_ERROR("Unable to initialize pm device");
		acc_hal_integration_deinit();
		return false;
	}

	if (!setup_isr())
	{
		ACC_LOG_ERROR("Unable to setup isr");
		acc_hal_integration_deinit();
		return false;
	}

	return true;
}


static void acc_hal_integration_deinit(void)
{
	acc_peripherals_xm112_deinit();

	if (NULL != spi_master_handle)
	{
		acc_spi_same70_destroy(&spi_master_handle);
	}

	if (NULL != spi_master_transfer_complete_semaphore)
	{
		acc_integration_semaphore_destroy(spi_master_transfer_complete_semaphore);
		spi_master_transfer_complete_semaphore = NULL;
	}

	if (NULL != isr_semaphore)
	{
		acc_integration_semaphore_destroy(isr_semaphore);
		isr_semaphore = NULL;
	}

	for (int i = 0; i < UART_IFACE_COUNT; i++)
	{
		if (NULL != uart_complete_semaphores[i])
		{
			acc_integration_semaphore_destroy(uart_complete_semaphores[i]);
		}
	}
}


void acc_hal_integration_start_sensor(acc_sensor_id_t sensor)
{
	(void)sensor;

	if (sensor_active)
	{
		ACC_LOG_ERROR("Sensor already active.");
		return;
	}

	if (!acc_gpio_same70_write(XM11x_PS_ENABLE_PIN, 1))
	{
		ACC_LOG_ERROR("Unable to activate PS_ENABLE");
		return;
	}

	if (!acc_gpio_same70_write(XM11x_SENS_EN_PIN, 1))
	{
		ACC_LOG_ERROR("Unable to activate SENS_EN");
		return;
	}

	// Crystal stabilization time is 1-2 ms
	// Sleep 3 ms just to be safe (sleep functions don't have to be accurate)
	acc_integration_sleep_ms(3);

	// Clear pending interrupts
	while (acc_integration_semaphore_wait(isr_semaphore, 0));

	sensor_active = true;
}


void acc_hal_integration_stop_sensor(acc_sensor_id_t sensor)
{
	(void)sensor;

	if (!sensor_active)
	{
		ACC_LOG_ERROR("Sensor already inactive.");
		return;
	}

	sensor_active = false;

	if (!acc_gpio_same70_write(XM11x_SENS_EN_PIN, 0))
	{
		ACC_LOG_WARNING("Unable to deactivate SENS_EN");
	}

	// t_wait according to integration specification at least 200 us
	// but timer resolution is in ms.
	acc_integration_sleep_ms(1);

	if (!acc_gpio_same70_write(XM11x_PS_ENABLE_PIN, 0))
	{
		ACC_LOG_WARNING("Unable to deactivate PS_ENABLE");
	}
}


void acc_hal_integration_sensor_transfer(acc_sensor_id_t sensor_id, uint8_t *buffer, size_t buffer_length)
{
	(void)sensor_id;

	acc_spi_same70_transfer(spi_master_handle, buffer, buffer_length);
}


bool acc_hal_integration_wait_for_sensor_interrupt(acc_sensor_id_t sensor_id, uint32_t timeout_ms)
{
	(void)sensor_id;
	return acc_integration_semaphore_wait(isr_semaphore, timeout_ms);
}


float acc_hal_integration_get_ref_freq(void)
{
	return XM11x_SENSOR_REFERENCE_FREQUENCY;
}


void set_led(bool enable)
{
	if (enable)
	{
		// Driving the pin low enables LED
		acc_gpio_same70_write(XM11x_LED_PIN, 0);
	}
	else
	{
		// Driving the pin high disables LED
		acc_gpio_same70_write(XM11x_LED_PIN, 1);
	}
}


static bool is_interrupt_context(void)
{
	uint32_t ipsr;

	asm ("mrs %0, ipsr" : "=r" (ipsr));
	return ipsr != 0;
}


static bool is_debugger_active(void)
{
	return CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk;
}


static bool is_service_mode(void)
{
	return GPBR->SYS_GPBR[GPBR_SERVICE_MODE_REGISTER] == GPBR_SERVICE_MODE_VALUE;
}


void system_fatal_error_handler(const char *reason)
{
	if (is_service_mode())
	{
		// We are in "service mode", ignore all errors and hope for the best
		return;
	}

	static mutex_t recursion = 0;
	if (!mutex_try_lock(&recursion))
	{
		/* We have ended here recursively, lets just reset
		 * silently as it seems like we are getting errors
		 * when executing code below
		 */
		if (is_debugger_active())
		{
			asm ("bkpt #3" ::: "memory");
		}

		rstc_reset_all();
	}

	/* Increase a non volatile counter that we also print
	 * in order to give an idea on how often this has happened.
	 */
	GPBR->SYS_GPBR[GPBR_ERROR_COUNTER_REGISTER]++;

	// Avoid logging in interrupt context as that will fail
	if (!is_interrupt_context())
	{
		ACC_LOG_ERROR("Error %s\n", reason);
		ACC_LOG_ERROR("error counter=%" PRIu32 ", rebooting\n",
		              GPBR->SYS_GPBR[GPBR_ERROR_COUNTER_REGISTER]);
	}

	if (is_debugger_active())
	{
		asm ("bkpt #3" ::: "memory");
	}

	rstc_reset_all();
	while (1);
}


void vApplicationMallocFailedHook(void)
{
	system_fatal_error_handler(__func__);
}


static const acc_hal_t hal =
{
	.properties.sensor_count          = 1,
	.properties.max_spi_transfer_size = ACC_SPI_SAME70_MAX_TRANSFER_SIZE,

	.sensor_device.power_on                = acc_hal_integration_start_sensor,
	.sensor_device.power_off               = acc_hal_integration_stop_sensor,
	.sensor_device.wait_for_interrupt      = acc_hal_integration_wait_for_sensor_interrupt,
	.sensor_device.transfer                = acc_hal_integration_sensor_transfer,
	.sensor_device.get_reference_frequency = acc_hal_integration_get_ref_freq,

	.sensor_device.hibernate_enter = NULL,
	.sensor_device.hibernate_exit  = NULL,

	.os.mem_alloc = acc_integration_mem_alloc,
	.os.mem_free  = acc_integration_mem_free,
	.os.gettime   = acc_integration_get_time,

	.log.log_level = ACC_LOG_LEVEL_INFO,
	.log.log       = acc_log
};


const acc_hal_t *acc_hal_integration_get_implementation(void)
{
	return &hal;
}
