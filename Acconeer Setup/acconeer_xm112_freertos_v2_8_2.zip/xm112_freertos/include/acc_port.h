// Copyright (c) Acconeer AB, 2018-2021
// All rights reserved

#ifndef ACC_PORT_H_
#define ACC_PORT_H_

#include <stdbool.h>

typedef enum
{
	/** No explicit sleep state active */
	ACC_POWER_STATE_RUNNING,
	/** System is in WFI, with clocks lowered. RAM in retention and regulators enabled. Wake on any interrupt */
	ACC_POWER_STATE_SLEEP,
	/** System in deep sleep and peripherals are powered down. RAM in retention and regulators enabled. Wake only on dedicated signals */
	ACC_POWER_STATE_DEEPSLEEP,
	/** System is in the lowest power state. All blocks are off and RAM is off. Wake only on dedicated signals */
	ACC_POWER_STATE_BACKUP,
} acc_port_power_state_t;

/**
 * @brief Initialize the power management device
 *
 * @param[in] req_wkup_gpio Wake up pin
 * @return Status
 */
bool acc_port_init(uint8_t req_wkup_gpio);


/**
 * @brief Set the power state the system can go at the lowest
 *
 * @param[in] req_power_state power state
 */
void acc_port_set_lowest_power_state(acc_port_power_state_t req_power_state);


/**
 * @brief Prevent the system from entering any low power state.
 *
 * Implemented as a counter that needs to be decreased using acc_port_wake_unlock
 */
void acc_port_wake_lock(void);


/**
 * @brief Remove the blocker from entering any low power state.
 *
 */
void acc_port_wake_unlock(void);


#endif
