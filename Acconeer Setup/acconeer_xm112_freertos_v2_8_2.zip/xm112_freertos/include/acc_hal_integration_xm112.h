// Copyright (c) Acconeer AB, 2021
// All rights reserved

#ifndef ACC_HAL_INTEGRATION_XM112_H_
#define ACC_HAL_INTEGRATION_XM112_H_

#include <stdbool.h>


#define XM11x_SPI_CS    (0)
#define XM11x_SPI_SPEED (48000000)


/**
 * @brief Initialize the HAL
 *
 * @return true if successful, else false.
 */
bool acc_hal_integration_xm112_init(void);


#endif
