// Copyright (c) Acconeer AB, 2017-2021
// All rights reserved

#ifndef ACC_SPI_SAME70_H_
#define ACC_SPI_SAME70_H_

#include <stdbool.h>


#define ACC_SPI_SAME70_MAX_TRANSFER_SIZE SIZE_MAX


struct acc_spi_same70_handle;

typedef struct acc_spi_same70_handle *acc_spi_same70_handle_t;

typedef struct
{
	uint8_t  group;
	uint32_t mask;
	uint8_t  type;
	uint32_t attribute;
} acc_spi_same70_pin_t;

typedef struct
{
	acc_spi_same70_pin_t spi_miso;
	acc_spi_same70_pin_t spi_mosi;
	acc_spi_same70_pin_t spi_clk;
	acc_spi_same70_pin_t spi_npcs;
} acc_spi_same70_pin_config_t;

typedef struct
{
	uint8_t  bus;
	uint8_t  device;
	uint32_t speed;
	bool     master;
	void     *configuration;
	uint32_t buffer_size;
} acc_spi_same70_configuration_t;

typedef enum
{
	acc_spi_same70_TRANSFER_STATUS_OK = 0,
	acc_spi_same70_TRANSFER_STATUS_ABORTED,
} acc_spi_same70_transfer_status_enum_t;
typedef uint32_t acc_spi_same70_transfer_status_t;

/**
 * @brief Function called by driver to wait for transfer complete.
 *
 * Typically this function waits for a semaphore that is signaled when the
 * acc_spi_same70_transfer_complete_callback_t is called.
 *
 * @param[in] handle The device handle
 */
typedef void (*acc_spi_same70_wait_for_transfer_complete_t)(acc_spi_same70_handle_t handle);

/**
 * @brief Function called by driver when transfer is complete
 *
 * Typically this function signals the semaphore that acc_spi_same70_wait_for_transfer_complete_t
 * is waiting for.
 *
 * @param[in] handle The device handle
 */
typedef void (*acc_spi_same70_transfer_complete_callback_t)(acc_spi_same70_handle_t handle);


/**
 * @brief Function that will be called when acc_spi_same70_transfer_async is done
 *
 * @param handle SPI device handle
 * @param status SPI the status of the transfer
 */
typedef void (*acc_spi_same70_transfer_callback_t)(acc_spi_same70_handle_t handle, acc_spi_same70_transfer_status_t status);


/**
 * @brief Create SPI device handle
 *
 * @param[in] configuration Configuration for the SPI device
 * @return Status
 */
acc_spi_same70_handle_t acc_spi_same70_create(acc_spi_same70_configuration_t *configuration);


/**
 * @brief Destroy SPI device handle
 *
 * @param[in] handle The handle to be destroyed
 */
void acc_spi_same70_destroy(acc_spi_same70_handle_t *handle);


/**
 * @brief Data transfer (SPI)
 *
 * @param handle SPI device handle
 * @param buffer The data to be transferred
 * @param buffer_size The size of the buffer in bytes
 * @return Status
 */
bool acc_spi_same70_transfer(
	acc_spi_same70_handle_t handle,
	uint8_t                 *buffer,
	size_t                  buffer_size);


/**
 * @brief Data transfer (SPI)
 *
 * @param handle SPI device handle
 * @param buffer The data to be transferred. The buffer must be valid until the transfer is completed.
 *               It is the callers responsibility to free the buffer once the transfer is finished
 * @param rx Enable rx of the transfer
 * @param tx Enable tx of the transfer
 * @param buffer_size The size of the buffer in bytes
 * @param[in] callback Callback function to be called when transfer is complete
 * @return Status
 */
bool acc_spi_same70_transfer_async(
	acc_spi_same70_handle_t            handle,
	uint8_t                            *buffer,
	bool                               rx,
	bool                               tx,
	size_t                             buffer_size,
	acc_spi_same70_transfer_callback_t callback);


/**
 * @brief Request driver to register with appropriate functions
 */
extern void acc_spi_same70_register(acc_spi_same70_wait_for_transfer_complete_t wait_function,
                                    acc_spi_same70_transfer_complete_callback_t transfer_complete);


#endif
