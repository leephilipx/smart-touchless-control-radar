// Copyright (c) Acconeer AB, 2017-2021
// All rights reserved

#ifndef ACC_GPIO_SAME70_H_
#define ACC_GPIO_SAME70_H_

#include <stdbool.h>
#include <stdint.h>

#include "acc_integration.h"

#include "pio.h"

typedef enum
{
	GPIO_DIR_IN,
	GPIO_DIR_OUT,
	GPIO_DIR_UNKNOWN
} acc_gpio_same70_dir_enum_t;

typedef enum
{
	ACC_GPIO_SAME70_EDGE_NONE,
	ACC_GPIO_SAME70_EDGE_FALLING,
	ACC_GPIO_SAME70_EDGE_RISING,
	ACC_GPIO_SAME70_EDGE_BOTH
} acc_gpio_same70_edge_t;

typedef uint32_t acc_gpio_same70_dir_t;
typedef void (*acc_gpio_same70_isr_t)(void);

/**
 * @brief GPIO pin information
 */
typedef struct
{
	uint8_t                 is_open;
	int8_t                  level;
	acc_gpio_same70_dir_t   dir;
	struct _pin             pin_struct;
	acc_integration_mutex_t mutex;
	acc_gpio_same70_isr_t   isr;
	bool                    init;
} acc_gpio_same70_t;


/**
 * @brief Initialize GPIO driver
 */
bool acc_gpio_same70_init(void);


/**
 * @brief Inform the driver of the pull up/down level for a GPIO pin after reset
 *
 * This function in this driver only opens the pin.
 *
 * The GPIO pin numbering is decided by the GPIO driver.
 *
 * @param[in] pin Pin number
 * @param[in] level The pull level 0 or 1
 */
bool acc_gpio_same70_set_initial_pull(uint8_t pin, uint8_t level);


/**
 * @brief Set GPIO to input
 *
 * This function sets the direction of a GPIO to input.
 * GPIO parameter is not a pin number but GPIO index (0-X).
 *
 * @param[in] pin GPIO pin to be set to input
 */
bool acc_gpio_same70_input(uint8_t pin);


/**
 * @brief Read from GPIO
 *
 * @param[in] pin GPIO pin to read
 * @param[out] value The value which has been read
 */
bool acc_gpio_same70_read(uint8_t pin, uint8_t *value);


/**
 * @brief Set GPIO output level
 *
 * This function sets a GPIO to output and the level to low or high.
 *
 * @param[in] pin GPIO pin to be set
 * @param[in] level 0 to 1 to set pin low or high
 */
bool acc_gpio_same70_write(uint8_t pin, uint8_t level);


/**
 * @brief Register an interrupt service routine for a GPIO pin
 *
 * Registers an interrupt service routine which will be called when the specified edge is detected on the selected GPIO pin.
 * If true is returned the interrupt service routine will immediately be triggered if the specified edge is detected.
 * If a new interrupt service routine is registered it will replace the old one.
 *
 * The interrupt service routine can be unregistered by register NULL.
 * Unregister an already unregistered interrupt service routine has no effect.
 *
 * @param pin GPIO pin the interrupt service routine will be attached to.
 * @param edge The edge that will trigger the interrupt service routine. Can be set to "falling", "rising" or both.
 * @param isr The function to be called when the specified edge is detected.
 * @return true if the interrupt service routine was registered, false if the specified pin does not
 *      support interrupts or if the registration failed.
 */
bool acc_gpio_same70_register_isr(uint8_t pin, acc_gpio_same70_edge_t edge, acc_gpio_same70_isr_t isr);


/**
 * @brief Request driver to register with appropriate device(s)
 *
 * @param[in] pin_count The maximum number of pins supported
 * @param[in] gpio_mem Memory to be used be GPIO driver
 */
void acc_gpio_same70_register(uint16_t pin_count, acc_gpio_same70_t *gpio_mem);


#endif
