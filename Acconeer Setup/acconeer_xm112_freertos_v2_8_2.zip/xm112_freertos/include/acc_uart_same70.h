// Copyright (c) Acconeer AB, 2017-2021
// All rights reserved

#ifndef ACC_UART_SAME70_H_
#define ACC_UART_SAME70_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/**
 * @brief Driver specific parameter
 */
typedef enum
{
	ACC_UART_SAME70_OPTIONS_ALT_PINS_1 = 1,
	ACC_UART_SAME70_OPTIONS_ALT_PINS_2 = 2,
	ACC_UART_SAME70_OPTIONS_ALT_PINS_3 = 4
} acc_uart_same70_options_enum_t;
typedef uint32_t acc_uart_same70_options_t;

typedef struct
{
	uint8_t  pwr_signal_pin;
	uint8_t  debug_uart_port;
	uint32_t debug_uart_port_baudrate;
	bool     enable_uart_debug;
	uint8_t  mop_uart_count;
	uint8_t  *mop_uart_ports;
} acc_uart_same70_config_t;


extern const acc_uart_same70_config_t acc_uart_same70_config;


/**
 * @brief Function called by driver to wait for transfer complete.
 *
 * Typically this function waits for a semaphore that is signaled when the
 * transfer_complete_callback_t is called.
 *
 * @param[in] port The port
 */
typedef void (*uart_wait_for_transfer_complete_t)(uint_fast8_t port);

/**
 * @brief Function called by driver when transfer is complete
 *
 * Typically this function signals the semaphore that wait_for_transfer_complete_t
 * is waiting for.
 *
 * @param[in] port The port
 */
typedef void (*uart_transfer_complete_callback_t)(uint_fast8_t port);

typedef void (acc_uart_same70_read_func_t)(uint_fast8_t port, uint8_t data, uint32_t status);


/**
 * @brief Initialize UART
 *
 * Init UART, set baudrate and prepare transmit/receive buffers
 *
 * @param port     The UART to configure
 * @param baudrate Baudrate to use
 * @param options  Driver specific parameter
 * @return True if successful, false otherwise
 */
bool acc_uart_same70_init(uint_fast8_t port, uint32_t baudrate, acc_uart_same70_options_t options);


/**
 * @brief Send array of data on UART
 *
 * @param port   The UART to use
 * @param data   The data buffer to be transmitted
 * @param length The length of the data
 * @return True if successful, false otherwise
 */
bool acc_uart_same70_write(uint_fast8_t port, const uint8_t *data, size_t length);


/**
 * @brief Used by the client to register a read callback
 * @param port	the UART port
 * @param callback Function pointer to the callback
 *
 */
void acc_uart_same70_register_read_callback(uint_fast8_t port, acc_uart_same70_read_func_t *callback);


/**
 * @brief Get the error count, typically overrun errors when receiving data
 * @param port the UART port
 *
 * @return 0 if no errors were found
 */
int32_t acc_uart_same70_get_error_count(uint_fast8_t port);


/**
 * @brief Deinitialize UART
 *
 * @param port the UART port
 *
 */
void acc_uart_same70_deinit(uint_fast8_t port);


/**
 * @brief Request driver to register with appropriate device(s)
 *
 * @param[in] wait_function     Called by driver to wait for transfer complete. See above
 *                              for more information.
 * @param[in] transfer_complete Called by driver when transfer is completed. See above
 *                              for more information.
 */
void acc_uart_same70_register(uart_wait_for_transfer_complete_t wait_function,
                              uart_transfer_complete_callback_t transfer_complete);


#endif
