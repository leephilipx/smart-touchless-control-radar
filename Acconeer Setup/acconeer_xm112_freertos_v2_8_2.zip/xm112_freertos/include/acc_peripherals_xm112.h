// Copyright (c) Acconeer AB, 2021
// All rights reserved

#ifndef ACC_PERIPHERALS_XM112_H_
#define ACC_PERIPHERALS_XM112_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "acc_i2c_same70.h"


/**
 * @brief Initializes peripherals.
 *
 * @return True if successful, false otherwise
 */
bool acc_peripherals_xm112_init(void);


/**
 * @brief Deinitializes peripherals
 *
 */
void acc_peripherals_xm112_deinit(void);


/**
 * @brief Reads temperature value.
 *
 * Read the temperature from the temperature sensor
 *
 * @param[out] temperature temperature value is returned
 * @return True if successful, false otherwise
 */
bool acc_peripherals_xm112_temperature_read(float *temperature);


/**
 * @brief Writes data to eeprom.
 *
 * The eeprom has to be initialized before this function is called.
 *
 * If size equals 0, false is returned.
 *
 * @param[in] address The memory address to start write at
 * @param[in] buffer The buffer containing the data to be written
 * @param[in] size The size in bytes of the data to be written
 * @return True if successful, false otherwise
 */
bool acc_peripherals_xm112_eeprom_write(uint32_t address, const void *buffer, size_t size);


/**
 * @brief Reads data from eeprom.
 *
 * The eeprom has to be initialized before this function is called.
 *
 * If size equals 0, false is returned
 *
 * @param[in] address The memory address to start read at
 * @param[out] buffer The buffer where the data should be stored
 * @param[in] size The size in bytes of the data to be read
 * @return True if successful, false otherwise
 */
bool acc_peripherals_xm112_eeprom_read(uint32_t address, void *buffer, size_t size);

#endif
