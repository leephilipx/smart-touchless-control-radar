This folder contains files from the "Atmel Software Package" project located at
https://github.com/atmelcorp/atmel-software-package

It is currently based on revision f2708384 with additional changes made by Acconeer AB.
