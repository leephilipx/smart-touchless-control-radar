clear all; close all; clc


filename = 'XM122 range(0.2m-1m),Max buffered frame 128,Update rate 30Hz, HWAAS =1 [press].h5';
info = h5info(filename);

data = h5read(filename, '/data');
disp("Data size =");
disp(size(data));
% Dimensions (frame, sensor, depth) for Envelope, IQ, Power bins
%            (frame, sensor, sweep, depth) for Sparse

data_info = jsondecode(string(h5read(filename, '/data_info')));
first_data_info = data_info(1, 1)  % (frame, sensor);

rss_version = string(h5read(filename, '/rss_version'));
lib_version = string(h5read(filename, '/lib_version'));
timestamp   = string(h5read(filename, '/timestamp'));

%end of loadtestfile

s1r = squeeze(data.r);
s1i = squeeze(data.i);
s1  = s1r + j*s1i;

[NTS Nframe]=size(s1)
Nrange = NTS;

Rmin   = 0.2;
Rmax   = 0.8;
Rstep  = 4.8400e-04;    % meter

% fast time axis to obtain range
% Range Vs Frame

FrameRate = 200;

%===================
R1abs = abs(s1);
axisRange = linspace(Rmin, Rmax, Nrange);   % 1x2272
axisFrame = [1:Nframe];                     % 1xNframe
axisTime  = axisFrame/FrameRate;            % 1xNframe

%The fast

[rPeak rIndex] = max(R1abs); 
R1abs = R1abs/max(rPeak);
rPeak = axisRange(rIndex);
rMaxcm = rPeak(500)*100; rMaxcm=round(rMaxcm*10)/10;
Tmax = round(max(axisTime)*100)/100;
y3tick=[Rmin*100 rMaxcm Rmax*100];


%Q2 = fft(s1r);
%I2 = fft(s1i);

plot(FrameRate,[rPeak rIndex],'-o')


figtitle1 = 'Spectrogram original and denoised sounds' ; 
xlabel({'$Time\hspace{1mm}{s}$'},...
        'Fontunits','points',...
        'interpreter','latex',...
        'Fontsize',12,...
        'FontName','Times')
ylabel({'$Amplitude\hspace{1mm}{y}$'},...
    'Fontunits','Points',...
    'Interpreter','Latex',...
    'FontSize',12,...
    'FontName','Times')
title({'$signal\hspace{1mm}:\hspace{1mm}plot$'},...
    'Fontunits','Points',...
    'interpreter','latex',...
    'FontSize',13,...
    'FontName','Times')
set(gcf,'paperpositionmode','auto')
print('x(t)','-r0')

figure('units','centimeters',...
    'position',[0 0 35 15],...
    'paperpositionmode','auto');
subplot(1,5,1)

NFFT=2*1024;                                % Non-Uniform Fast Fourier Transform
window_length=2*round(0.031*FrameRate);     % the height and width in pixels of a square window that slides across (scans) your image.
window=hamming(window_length);
window = window(:);
overlap = floor(0.45*window_length);
[S,F,T]= spectrogram([rPeak rIndex],window,window_length-overlap,NFFT,FrameRate,'yaxis')
[Nf,Nw]= size(S);
t_epsilon = 0.00001;
S_one_sided=max(S(1:fix(length(F)/2),:),t_epsilon);
pcolor(T,F(1:fix(Nf/2)),10*log(abs(S_one_sided)));
shading interp;
colormap('jet');
title('spectrogram: rectwin');
set(gca, 'Xminortick','on', 'XminorGrid', 'on')
set(gca, 'Xminortick','on','XminorGrid','on')
xlabel({'$Time\hspace{1mm}{s}$'},...
    'FontUnits','Points',...
    'interpreter','latex',...
    'Fontsize',12,...
    'FontName','Times')
ylabel({'$Frequency\hspace[1mm][hz]$'},...
    'FontUnits','Points',...
    'interpreter','latex',...
    'Fontsize',12,...
    'FontName','Times')

title({'$Spectrogram\hspace{1mm}:\hspace{1mm}hamming$'},...
   'FontUnits','Points',...
   'Fontweight','Normal',...
    'interpreter','latex',...
    'Fontsize',12,...
    'FontName','Times')

hold on


%--------------------------------------------------------------
fh1=figure(3);  % Range vs frame
    surf(axisFrame, axisRange*100, R1abs); 
    colormap(jet)
    shading interp
    xlim([1 Nframe]); 
    ylim([Rmin Rmax]*100); 
    zlim([0 1])
    xlabel('Sweep','fontsize',12)
    ylabel('Distance (cm)','fontsize',12)
    title('Output signal profile','fontsize',12)
    set(gca,'XTick',[1 200:200:Nframe],'YTick',y3tick,'ZTick',[0 1])
    view(45,60)
set(fh1,'Position',[10 550 500 400])
print -djpeg fig1_surf.jpg;

%--------------------------------------------------------------
R1db=20*log10(R1abs);
fh2=figure(4); % Range vs Time
    imagesc(axisFrame, axisRange*100, R1db, [-20 0]);
    xlabel('Sweep','fontsize',12)
    ylabel('Range (cm)','fontsize',12);
    title('Output signal profile','fontsize',12)    
    colormap(jet); colorbar
    xlim([1 Nframe]);
    ylim([Rmin Rmax]*100)
    set(gca,'YDir','normal','XTick',[1 200:200:Nframe],'YTick',y3tick)
    set(fh2,'Position',[10 60 500 400])
print -djpeg fig2_RangeSweep.jpg

% Axis  
%figure ; plot(1:length(Q2),R1db) ; hold on ; plot(1:length(Q2), I2); hold off;




%eof
 
